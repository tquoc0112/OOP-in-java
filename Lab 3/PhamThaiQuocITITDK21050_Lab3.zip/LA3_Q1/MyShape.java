package LA3_Q1;

public class MyShape {
    public void Draw(){
        
    }
}
