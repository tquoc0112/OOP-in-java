package LA3_Q1;

public class MyBoundedShape extends MyShape {
    public void GetArea(){
    private int x;
    private int y;
    public double GetArea(){
        
    }
}
