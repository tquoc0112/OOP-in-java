package LA3_Q1;

public class MyLine extends MyShape {
    
}
