package LA3_Q2;

public class MyPoint extends MyTriangle {
    public MyPoint
}
