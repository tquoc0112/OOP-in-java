package LA3_Q2;

public class MyTriangle {
    
}
