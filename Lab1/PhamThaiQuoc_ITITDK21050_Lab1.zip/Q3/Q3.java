//ITITDK21050 PhamThaiQuoc
package Lab1.Q3;

public class Q3 
{
    public static void main(String[] args)
    {
        Distance d1 = new Distance(1,2,3,4);
        d1.CalculateDistance();
    }
}