//ITITDK21050 PhamThaiQuoc
package Lab1.Q1;


public class Q1
{    
    public static void main(String[] args)
    {
        Rectangle rectangle1 = new Rectangle(3,4);
        Rectangle rectangle2 = new Rectangle(-3,8);
        Rectangle rectangle3 = new Rectangle(3,-6);
        Rectangle rectangle4 = new Rectangle(1,5);
        Rectangle rectangle5 = new Rectangle(2,7);
        
    //First Rectangle visuallization:
        System.out.println("First Triangle\n");
        rectangle1.VisualizeRectangle();
    //2nd Rectangle visuallization:
        System.out.println("2nd Triangle\n");
        rectangle2.VisualizeRectangle();
    //3rd Rectangle visuallization:
        System.out.println("3rd Triangle\n");
        rectangle3.VisualizeRectangle();
    //4th Rectangle visuallization:
        System.out.println("4th Triangle\n");
        rectangle4.VisualizeRectangle();
    //5th Rectangle visuallization:
        System.out.println("4th Triangle\n");
        rectangle5.VisualizeRectangle();
    }
}