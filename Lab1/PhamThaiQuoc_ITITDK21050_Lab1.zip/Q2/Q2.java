//ITITDK21050 PhamThaiQuoc
package Lab1.Q2;

class Q2
{    
    public static void main(String[] args)
    {
        Triangle t1 = new Triangle(7, 5, 4);
        Triangle t2 = new Triangle(4, 2, 4);
        Triangle t3 = new Triangle(3, 3, 3);
        Triangle t4 = new Triangle(1, 2, 3);
        //
        t1.getA();
        t1.getB();
        t1.getC();
        t1.Verify();
        //
        t2.getA();
        t2.getB();
        t2.getC();
        t2.Verify();
        //
        t3.getA();
        t3.getB();
        t3.getC();;
        t3.Verify();
        //
        t4.getA();
        t4.getB();
        t4.getC();        
        t4.Verify();
    }
}