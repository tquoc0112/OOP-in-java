
package Lab1.Q4;
class Item {
    public String name;
    public int id;
    public double price;
}
